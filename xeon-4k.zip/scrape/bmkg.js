const axios = require('axios')

async function bmkg() {
    return new Promise((resolve, reject) => {
        axios.get('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json')
        .then(({ data }) => {
            let hasil = {
                tanggal: data.Infogempa.gempa.Tanggal,
                jam: data.Infogempa.gempa.Jam,
                date_time: data.Infogempa.gempa.DateTime,
                koordinat: data.Infogempa.gempa.Coordinates,
                lintang: data.Infogempa.gempa.Lintang,
                bujur: data.Infogempa.gempa.Bujur,
                magnitudo: data.Infogempa.gempa.Magnitude,
                kedalaman: data.Infogempa.gempa.Kedalaman,
                wilayah: data.Infogempa.gempa.Wilayah,
                potensi: data.Infogempa.gempa.Potensi,
                dirasakan: data.Infogempa.gempa.Dirasakan,
                gambar: 'https://data.bmkg.go.id/DataMKG/TEWS/' +data.Infogempa.gempa.Shakemap
            }
            resolve(hasil)
        })
    })
}

module.exports.bmkg = bmkg